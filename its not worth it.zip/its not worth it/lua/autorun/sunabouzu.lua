player_manager.AddValidModel( "Sunabouzu",                     "models/player/sunabouzu.mdl" )
list.Set( "PlayerOptionsModel",  "sunabouzu",                     "models/player/sunabouzu.mdl" ) 